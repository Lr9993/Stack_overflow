import mongoose from "mongoose";

const connectDB = async () => {
  try {
    await mongoose.connect("mongodb://10.100.142.136:27017", { 
      useNewUrlParser: true, 
      useUnifiedTopology: true 
    })
    console.log(`Connected to MongoDB successfully`)
  } catch (error) {
    console.log(`MongoDB Error: ${error}`)
  }
}

export default connectDB